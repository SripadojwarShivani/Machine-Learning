package com.management.Content;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Repository extends JpaRepository <Content,Long> {
}
